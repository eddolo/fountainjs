# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: virtual-selection-real.spec.ts >> replaces and restores selections across offscreen document content
- Location: tests\manual\virtual-selection-real.spec.ts:4:1

# Error details

```
Test timeout of 90000ms exceeded.
```

```
Error: page.waitForEvent: Test timeout of 90000ms exceeded.
=========================== logs ===========================
waiting for event "download"
============================================================
```

# Page snapshot

```yaml
- main [ref=e3]:
  - generic [ref=e4]:
    - link "F FountainJS" [ref=e5] [cursor=pointer]:
      - /url: ./
      - generic [ref=e6]: F
      - text: FountainJS
    - navigation "Primary navigation" [ref=e7]:
      - link "Home" [ref=e8] [cursor=pointer]:
        - /url: ./
        - generic [ref=e10]: ↗
      - link "10 demos" [ref=e11] [cursor=pointer]:
        - /url: ./demos.html
        - generic [ref=e13]: ↗
      - link "Workflows" [ref=e14] [cursor=pointer]:
        - /url: ./workflows.html
        - generic [ref=e16]: ↗
      - link "Developers" [ref=e17] [cursor=pointer]:
        - /url: ./developers.html
        - generic [ref=e19]: ↗
    - link "How this is built ↓" [ref=e20] [cursor=pointer]:
      - /url: "#integration"
  - generic [ref=e21]:
    - generic [ref=e22]:
      - navigation "Breadcrumb" [ref=e23]:
        - list [ref=e24]:
          - listitem [ref=e25]:
            - link "Home" [ref=e26] [cursor=pointer]:
              - /url: ./
          - listitem [ref=e27]:
            - generic [ref=e28]: /
            - link "Workflow lab" [ref=e29] [cursor=pointer]:
              - /url: ./workflows.html
          - listitem [ref=e30]:
            - generic [ref=e31]: /
            - generic [ref=e32]: GitLab-style issue editor (unofficial)
        - link "Back to workflow lab" [ref=e33] [cursor=pointer]:
          - /url: ./workflows.html
          - generic [ref=e34]: ←
          - text: Back to workflow lab
      - heading "A bug report, from draft to review." [level=1] [ref=e35]
      - paragraph [ref=e36]: Write visually, inspect the Markdown, and preview what a reader sees. This is a FountainJS implementation of an issue-writing workflow, not a GitLab integration or a full GitLab Flavored Markdown implementation.
      - generic [ref=e37]:
        - text: Issue title
        - textbox "Issue title" [ref=e38]: Room switch leaves stale content
      - region "Issue description" [ref=e39]:
        - navigation "Description mode" [ref=e40]:
          - button "Visual editor" [pressed] [ref=e41] [cursor=pointer]
          - button "Markdown source" [ref=e42] [cursor=pointer]
          - button "Reader preview" [ref=e43] [cursor=pointer]
        - generic [ref=e45]:
          - toolbar "Formatting and rich content" [ref=e47]:
            - group "History and search" [ref=e48]:
              - button "Undo" [ref=e49] [cursor=pointer]
              - button "Redo" [ref=e50] [cursor=pointer]
              - button "Find and replace" [ref=e51] [cursor=pointer]
            - group "Block types" [ref=e52]:
              - button "Paragraph" [ref=e53] [cursor=pointer]
              - button "H1 — Heading 1" [ref=e54] [cursor=pointer]:
                - img:
                  - generic: H1
              - button "H2 — Heading 2" [ref=e55] [cursor=pointer]:
                - img:
                  - generic: H2
              - button "H3 — Heading 3" [ref=e56] [cursor=pointer]:
                - img:
                  - generic: H3
            - group "Text formatting" [ref=e57]:
              - button "Bold" [ref=e58] [cursor=pointer]
              - button "Italic" [ref=e59] [cursor=pointer]
              - button "Strikethrough" [ref=e60] [cursor=pointer]
              - button "Inline code" [ref=e61] [cursor=pointer]
              - button "Add or edit link" [ref=e62] [cursor=pointer]
              - button "Remove link" [disabled] [ref=e63]
            - group "Insert rich content" [ref=e64]:
              - button "Insert definition list" [ref=e65] [cursor=pointer]
              - button "Quote selected blocks" [ref=e66] [cursor=pointer]
              - button "Bullet list" [ref=e67] [cursor=pointer]
              - button "123 — Numbered list" [ref=e68] [cursor=pointer]:
                - img:
                  - generic: "1"
                  - generic: "2"
                  - generic: "3"
              - button "Task list" [ref=e69] [cursor=pointer]
              - button "Lift list item" [disabled] [ref=e70]
              - button "Indent list item" [disabled] [ref=e71]
              - button "Code block and language" [ref=e72] [cursor=pointer]
              - button "Insert table" [ref=e73] [cursor=pointer]
              - button "Insert image from URL" [ref=e74] [cursor=pointer]
              - button "Upload image" [ref=e75] [cursor=pointer]
              - button "Divider" [ref=e76] [cursor=pointer]
              - button "Line break" [ref=e77] [cursor=pointer]
          - textbox "Issue description editor" [ref=e79]:
            - heading "Navigation audit" [level=1] [ref=e80]
            - paragraph [ref=e81]: Anchor paragraph.
            - paragraph [ref=e82]: Paragraph 4969.
            - paragraph [ref=e83]: Paragraph 4970.
            - paragraph [ref=e84]: Paragraph 4971.
            - paragraph [ref=e85]: Paragraph 4972.
            - paragraph [ref=e86]: Paragraph 4973.
            - paragraph [ref=e87]: Paragraph 4974.
            - paragraph [ref=e88]: Paragraph 4975.
            - paragraph [ref=e89]: Paragraph 4976.
            - paragraph [ref=e90]: Paragraph 4977.
            - paragraph [ref=e91]: Paragraph 4978.
            - paragraph [ref=e92]: Paragraph 4979.
            - paragraph [ref=e93]: Paragraph 4980.
            - paragraph [ref=e94]: Paragraph 4981.
            - paragraph [ref=e95]: Paragraph 4982.
            - paragraph [ref=e96]: Paragraph 4983.
            - paragraph [ref=e97]: Paragraph 4984.
            - paragraph [ref=e98]: Paragraph 4985.
            - paragraph [ref=e99]: Paragraph 4986.
            - paragraph [ref=e100]: Paragraph 4987.
            - paragraph [ref=e101]: Paragraph 4988.
            - paragraph [ref=e102]: Paragraph 4989.
            - paragraph [ref=e103]: Paragraph 4990.
            - paragraph [ref=e104]: Paragraph 4991.
            - paragraph [ref=e105]: Paragraph 4992.
            - paragraph [ref=e106]: Paragraph 4993.
            - paragraph [ref=e107]: Paragraph 4994.
            - paragraph [ref=e108]: Paragraph 4995.
            - paragraph [ref=e109]: Paragraph 4996.
            - paragraph [ref=e110]: Paragraph 4997.
            - paragraph [ref=e111]: Paragraph 4998.
            - paragraph [ref=e112]: Paragraph 4999.
      - generic [ref=e113]:
        - generic [ref=e114]: Table export
        - combobox "Table export" [ref=e115]:
          - option "Markdown pipes · widest compatibility" [selected]
          - option "HTML tables · preserve cell structure"
      - paragraph [ref=e116]: HTML tables retain supported cell roles, spans and rich content when reopened here. Other readers must support HTML tables. This choice affects regenerated tables; untouched source stays unchanged. In source mode, download saves your raw text as written.
      - generic [ref=e117]:
        - button "Download Markdown draft" [active] [ref=e118] [cursor=pointer]
        - button "Open Markdown draft" [ref=e119] [cursor=pointer]
      - status [ref=e120]: Downloaded description Markdown. Keep the host title separately; this does not create an online issue.
    - complementary "Fountain diagnostics" [ref=e121]:
      - heading "Fountain diagnostics" [level=2] [ref=e122]
      - button "Check Markdown export" [ref=e123] [cursor=pointer]
      - paragraph [ref=e124]: Check the current draft before sharing. Opening source or downloading also checks it; editing stays separate.
      - generic [ref=e125]:
        - term [ref=e126]: Engine
        - definition [ref=e127]: FountainJS · React surface
        - term [ref=e128]: Document blocks
        - definition [ref=e129]: 5001 top-level blocks
        - term [ref=e130]: Source preservation
        - definition [ref=e131]: Not checked for this draft
        - term [ref=e132]: Export warnings
        - definition [ref=e133]: Not checked for this draft
        - term [ref=e134]: Images
        - definition [ref=e135]: Local raster uploads · imported image URLs may load remotely
        - term [ref=e136]: Collaboration / pagination
        - definition [ref=e137]: Not enabled in this workflow
        - term [ref=e138]: Viewport rendering
        - definition [ref=e139]: Enabled above 250 top-level blocks
        - term [ref=e140]: Server runtimes
        - definition [ref=e141]: Not measured by this page
      - group [ref=e142]:
        - generic "What does preservation mean?" [ref=e143] [cursor=pointer]
      - generic [ref=e144]:
        - heading "Try the source-fidelity check" [level=3] [ref=e145]
        - list [ref=e146]:
          - listitem [ref=e147]: Open Markdown source and find the tilde code fence and double underscores.
          - listitem [ref=e148]: Return to Visual editor. Edit only the first paragraph.
          - listitem [ref=e149]: Switch back. Check that the untouched source is still there.
          - listitem [ref=e150]: Download, reopen, and preview your draft.
  - generic [ref=e151]:
    - heading "Build this into your product" [level=2] [ref=e152]
    - paragraph [ref=e153]:
      - text: The host owns the title, file controls and submission. Fountain owns the description model, history, selection and formatting. Switching modes uses
      - code [ref=e154]: parseWithSource
      - text: ","
      - code [ref=e155]: exportWithSource
      - text: and a document-replacement transaction. The preview creates a separate read-only editor; read-only UI is not access control.
    - paragraph [ref=e156]: Images here use a bounded local file adapter. A real issue tracker supplies its own authenticated upload service, permissions and API submission. Drafts are not automatically persisted. External links and images in imported content may make network requests; this is not an offline sandbox.
    - paragraph [ref=e157]:
      - link "Developer guide ↗" [ref=e158] [cursor=pointer]:
        - /url: ./developers.html
      - text: ·
      - link "Workflow API walkthrough ↗" [ref=e159] [cursor=pointer]:
        - /url: https://github.com/eddolo/fountainjs/blob/master/docs/ISSUE_EDITOR_DEMO.md
      - text: ·
      - link "Demo source ↗" [ref=e160] [cursor=pointer]:
        - /url: https://github.com/eddolo/fountainjs/blob/master/examples/react-app/src/IssueEditor.tsx
```

# Test source

```ts
  1   | import { expect, type Page, type TestInfo } from '@playwright/test';
  2   | import { mkdir, readFile, writeFile } from 'node:fs/promises';
  3   | import { resolve } from 'node:path';
  4   | import { MarkdownImporter, Schema, StarterKit } from 'fountainjs-editor';
  5   | import { issueMarkdownOptions } from '../../examples/react-app/src/issue-markdown-policy';
  6   | 
  7   | export async function runVirtualSelectionJourney(page: Page, info: TestInfo): Promise<void> {
  8   |   const root = info.outputPath('virtual-selection-journey');
  9   |   await mkdir(root, { recursive: true });
  10  |   const firstText = 'Anchor paragraph.';
  11  |   const lastText = 'Paragraph 4999.';
  12  |   const source = '# Navigation audit\n\n' + firstText + '\n\n'
  13  |     + Array.from({ length: 4999 }, (_, index) => `Paragraph ${index + 1}.\n\n`).join('');
  14  |   await writeFile(resolve(root, 'original.md'), source);
  15  |   const errors: string[] = [];
  16  |   page.on('pageerror', error => errors.push(error.message));
  17  |   await page.goto('/issue-editor.html');
  18  |   const upload = page.getByLabel('Open Markdown draft file', { exact: true });
  19  |   await upload.setInputFiles({ name: 'navigation.md', mimeType: 'text/markdown', buffer: Buffer.from(source) });
  20  |   const editor = page.getByRole('textbox', { name: 'Issue description editor', exact: true });
  21  |   const blocks = page.getByRole('complementary', { name: 'Fountain diagnostics' }).locator('dt:has-text("Document blocks") + dd');
  22  |   await expect(blocks).toHaveText('5001 top-level blocks');
  23  |   expect(await editor.locator(':scope > p').count()).toBeLessThan(200);
  24  |   const native = () => page.evaluate(() => {
  25  |     const selection = document.getSelection();
  26  |     const path = (node: Node | null | undefined) => (node instanceof Element ? node : node?.parentElement)
  27  |       ?.closest('[data-fountain-text-path]')?.getAttribute('data-fountain-text-path') ?? null;
  28  |     return { anchor: path(selection?.anchorNode), anchorOffset: selection?.anchorOffset,
  29  |       focus: path(selection?.focusNode), focusOffset: selection?.focusOffset, collapsed: selection?.isCollapsed };
  30  |   });
  31  |   const first = editor.locator(':scope > p[data-fountain-path="1"]');
  32  |   await first.click();
  33  |   await page.keyboard.press('End');
  34  |   const ranges = [];
  35  |   for (const key of ['End', 'Home', 'End']) {
  36  |     await page.keyboard.press(`Control+Shift+${key}`);
  37  |     const expected = { anchor: '1.0', anchorOffset: firstText.length, focus: key === 'End' ? '5000.0' : '0.0',
  38  |       focusOffset: key === 'End' ? lastText.length : 0, collapsed: false };
  39  |     await expect.poll(native).toEqual(expected);
  40  |     ranges.push({ key, selection: await native() });
  41  |   }
  42  |   await page.screenshot({ path: resolve(root, 'forward-range.png') });
  43  |   // Replacement must remove every selected offscreen paragraph, not only the
  44  |   // DOM fragments currently mounted at the native selection's endpoints.
  45  |   await page.keyboard.type(' Replacement.');
  46  |   await expect(blocks).toHaveText('2 top-level blocks');
  47  |   await expect(editor.getByRole('heading', { name: 'Navigation audit', exact: true })).toBeVisible();
  48  |   await expect(editor.locator(':scope > p')).toHaveText(firstText + ' Replacement.');
  49  |   const schema = new Schema(StarterKit.schema);
  50  |   const original = MarkdownImporter.parse(source, schema, issueMarkdownOptions);
  51  |   const expectedDoc = original.copy([original.child(0), schema.node('paragraph', {}, [schema.text(firstText + ' Replacement.')])]);
  52  |   const download = async (name: string) => {
> 53  |     const event = page.waitForEvent('download');
      |                        ^ Error: page.waitForEvent: Test timeout of 90000ms exceeded.
  54  |     await page.getByRole('button', { name: 'Download Markdown draft', exact: true }).click();
  55  |     const path = resolve(root, name);
  56  |     await (await event).saveAs(path);
  57  |     return readFile(path, 'utf8');
  58  |   };
  59  |   const changed = await download('replacement.md');
  60  |   expect(MarkdownImporter.parse(changed, schema, issueMarkdownOptions).eq(expectedDoc)).toBe(true);
  61  |   await page.screenshot({ path: resolve(root, 'replaced.png') });
  62  |   const undo = page.getByRole('button', { name: 'Undo', exact: true });
  63  |   const redo = page.getByRole('button', { name: 'Redo', exact: true });
  64  |   await undo.click();
  65  |   await expect(blocks).toHaveText('5001 top-level blocks');
  66  |   expect(await download('undone.md')).toBe(source);
  67  |   await redo.click();
  68  |   await expect(blocks).toHaveText('2 top-level blocks');
  69  |   expect(await download('redone.md')).toBe(changed);
  70  |   await undo.click();
  71  |   await expect(blocks).toHaveText('5001 top-level blocks');
  72  |   await first.click();
  73  |   await page.keyboard.press('End');
  74  |   await page.keyboard.press('Control+End');
  75  |   await page.keyboard.press('Control+Shift+Home');
  76  |   await expect.poll(native).toEqual({ anchor: '5000.0', anchorOffset: lastText.length, focus: '0.0', focusOffset: 0, collapsed: false });
  77  |   await page.keyboard.type('Entire replacement.');
  78  |   await expect(blocks).toHaveText('1 top-level blocks');
  79  |   const whole = await download('whole-replacement.md');
  80  |   const wholeExpected = original.copy([schema.node('heading', original.child(0).attrs, [schema.text('Entire replacement.')])]);
  81  |   expect(MarkdownImporter.parse(whole, schema, issueMarkdownOptions).eq(wholeExpected)).toBe(true);
  82  |   await undo.click();
  83  |   await expect(blocks).toHaveText('5001 top-level blocks');
  84  |   expect(await download('whole-undone.md')).toBe(source);
  85  |   await page.getByRole('button', { name: 'Reader preview', exact: true }).click();
  86  |   const reader = page.getByRole('textbox', { name: 'Issue preview', exact: true });
  87  |   await expect(reader).toHaveAttribute('contenteditable', 'false');
  88  |   await reader.locator(':scope > p[data-fountain-path="1"]').click();
  89  |   await page.keyboard.press('End');
  90  |   for (const key of ['End', 'Home']) {
  91  |     await page.keyboard.press(`Control+Shift+${key}`);
  92  |     await expect.poll(native).toEqual({ anchor: '1.0', anchorOffset: firstText.length, focus: key === 'End' ? '5000.0' : '0.0',
  93  |       focusOffset: key === 'End' ? lastText.length : 0, collapsed: false });
  94  |   }
  95  |   await page.screenshot({ path: resolve(root, 'reader-range.png') });
  96  |   expect(await download('reader.md')).toBe(source);
  97  |   expect(errors).toEqual([]);
  98  |   await writeFile(resolve(root, 'observations.json'), JSON.stringify({ engine: info.project.name, ranges,
  99  |     forwardReplacementIncludesOffscreenContent: true, wholeBackwardReplacement: true, undoRedoRestoresCompleteSource: true,
  100 |     readerAnchorRetained: true, errors }, null, 2));
  101 | }
  102 | 
```