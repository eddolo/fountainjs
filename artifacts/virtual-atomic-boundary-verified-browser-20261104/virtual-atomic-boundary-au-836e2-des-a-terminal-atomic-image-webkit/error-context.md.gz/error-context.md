# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: virtual-atomic-boundary-audit-20261104.spec.ts >> document-boundary replacement includes a terminal atomic image
- Location: artifacts\virtual-atomic-boundary-audit-20261104.spec.ts:6:1

# Error details

```
Error: A full document-boundary selection must include the terminal atomic block.

expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 1
```

# Page snapshot

```yaml
- main [ref=e3]:
  - generic [ref=e4]:
    - link "F FountainJS" [ref=e5]:
      - /url: ./
      - generic [ref=e6]: F
      - text: FountainJS
    - navigation "Primary navigation" [ref=e7]:
      - link "Home" [ref=e8]:
        - /url: ./
        - generic [ref=e10]: ↗
      - link "10 demos" [ref=e11]:
        - /url: ./demos.html
        - generic [ref=e13]: ↗
      - link "Workflows" [ref=e14]:
        - /url: ./workflows.html
        - generic [ref=e16]: ↗
      - link "Developers" [ref=e17]:
        - /url: ./developers.html
        - generic [ref=e19]: ↗
    - link "How this is built ↓" [ref=e20]:
      - /url: "#integration"
  - generic [ref=e21]:
    - generic [ref=e22]:
      - navigation "Breadcrumb" [ref=e23]:
        - list [ref=e24]:
          - listitem [ref=e25]:
            - link "Home" [ref=e26]:
              - /url: ./
          - listitem [ref=e27]:
            - generic [ref=e28]: /
            - link "Workflow lab" [ref=e29]:
              - /url: ./workflows.html
          - listitem [ref=e30]:
            - generic [ref=e31]: /
            - generic [ref=e32]: GitLab-style issue editor (unofficial)
        - link "Back to workflow lab" [ref=e33]:
          - /url: ./workflows.html
          - generic [ref=e34]: ←
          - text: Back to workflow lab
      - heading "A bug report, from draft to review." [level=1] [ref=e35]
      - paragraph [ref=e36]: Write visually, inspect the Markdown, and preview what a reader sees. This is a FountainJS implementation of an issue-writing workflow, not a GitLab integration or a full GitLab Flavored Markdown implementation.
      - generic [ref=e37]:
        - text: Issue title
        - textbox "Issue title" [ref=e38]: Room switch leaves stale content
      - region "Issue description" [ref=e39]:
        - navigation "Description mode" [ref=e40]:
          - button "Visual editor" [pressed] [ref=e41] [cursor=pointer]
          - button "Markdown source" [ref=e42] [cursor=pointer]
          - button "Reader preview" [ref=e43] [cursor=pointer]
        - generic [ref=e45]:
          - toolbar "Formatting and rich content" [ref=e47]:
            - group "History and search" [ref=e48]:
              - button "Undo" [ref=e49] [cursor=pointer]
              - button "Redo" [disabled] [ref=e50]
              - button "Find and replace" [ref=e51] [cursor=pointer]
            - group "Block types" [ref=e52]:
              - button "Paragraph" [ref=e53] [cursor=pointer]
              - button "H1 — Heading 1" [ref=e54] [cursor=pointer]:
                - img:
                  - generic: H1
              - button "H2 — Heading 2" [ref=e55] [cursor=pointer]:
                - img:
                  - generic: H2
              - button "H3 — Heading 3" [ref=e56] [cursor=pointer]:
                - img:
                  - generic: H3
            - group "Text formatting" [ref=e57]:
              - button "Bold" [ref=e58] [cursor=pointer]
              - button "Italic" [ref=e59] [cursor=pointer]
              - button "Strikethrough" [ref=e60] [cursor=pointer]
              - button "Inline code" [ref=e61] [cursor=pointer]
              - button "Add or edit link" [ref=e62] [cursor=pointer]
              - button "Remove link" [disabled] [ref=e63]
            - group "Insert rich content" [ref=e64]:
              - button "Insert definition list" [ref=e65] [cursor=pointer]
              - button "Quote selected blocks" [ref=e66] [cursor=pointer]
              - button "Bullet list" [ref=e67] [cursor=pointer]
              - button "123 — Numbered list" [ref=e68] [cursor=pointer]:
                - img:
                  - generic: "1"
                  - generic: "2"
                  - generic: "3"
              - button "Task list" [ref=e69] [cursor=pointer]
              - button "Lift list item" [disabled] [ref=e70]
              - button "Indent list item" [disabled] [ref=e71]
              - button "Code block and language" [ref=e72] [cursor=pointer]
              - button "Insert table" [ref=e73] [cursor=pointer]
              - button "Insert image from URL" [ref=e74] [cursor=pointer]
              - button "Upload image" [ref=e75] [cursor=pointer]
              - button "Divider" [ref=e76] [cursor=pointer]
              - button "Line break" [ref=e77] [cursor=pointer]
          - textbox "Issue description editor" [ref=e79]:
            - paragraph [ref=e80]: Entire replacement.
            - 'figure "[Image: Terminal figure]" [ref=e81]':
              - img "Terminal figure" [ref=e82]
              - textbox "Image caption" [ref=e85]:
                - /placeholder: Add a caption
              - generic:
                - slider "Resize image from left" [ref=e86]
                - slider "Resize image from right" [ref=e87]
      - generic [ref=e88]:
        - generic [ref=e89]: Table export
        - combobox "Table export" [ref=e90]:
          - option "Markdown pipes · widest compatibility" [selected]
          - option "HTML tables · preserve cell structure"
      - paragraph [ref=e91]: HTML tables retain supported cell roles, spans and rich content when reopened here. Other readers must support HTML tables. This choice affects regenerated tables; untouched source stays unchanged. In source mode, download saves your raw text as written.
      - generic [ref=e92]:
        - button "Download Markdown draft" [ref=e93] [cursor=pointer]
        - button "Open Markdown draft" [ref=e94] [cursor=pointer]
      - status [ref=e95]: Downloaded description Markdown. Keep the host title separately; this does not create an online issue.
    - complementary "Fountain diagnostics" [ref=e96]:
      - heading "Fountain diagnostics" [level=2] [ref=e97]
      - button "Check Markdown export" [ref=e98] [cursor=pointer]
      - paragraph [ref=e99]: Check the current draft before sharing. Opening source or downloading also checks it; editing stays separate.
      - generic [ref=e100]:
        - term [ref=e101]: Engine
        - definition [ref=e102]: FountainJS · React surface
        - term [ref=e103]: Document blocks
        - definition [ref=e104]: 2 top-level blocks
        - term [ref=e105]: Source preservation
        - definition [ref=e106]: mapped-blocks
        - term [ref=e107]: Export warnings
        - definition [ref=e108]: "0"
        - term [ref=e109]: Images
        - definition [ref=e110]: Local raster uploads · imported image URLs may load remotely
        - term [ref=e111]: Collaboration / pagination
        - definition [ref=e112]: Not enabled in this workflow
        - term [ref=e113]: Viewport rendering
        - definition [ref=e114]: Enabled above 250 top-level blocks
        - term [ref=e115]: Server runtimes
        - definition [ref=e116]: Not measured by this page
      - group [ref=e117]:
        - generic "What does preservation mean?" [ref=e118] [cursor=pointer]
      - generic [ref=e119]:
        - heading "Try the source-fidelity check" [level=3] [ref=e120]
        - list [ref=e121]:
          - listitem [ref=e122]: Open Markdown source and find the tilde code fence and double underscores.
          - listitem [ref=e123]: Return to Visual editor. Edit only the first paragraph.
          - listitem [ref=e124]: Switch back. Check that the untouched source is still there.
          - listitem [ref=e125]: Download, reopen, and preview your draft.
  - generic [ref=e126]:
    - heading "Build this into your product" [level=2] [ref=e127]
    - paragraph [ref=e128]:
      - text: The host owns the title, file controls and submission. Fountain owns the description model, history, selection and formatting. Switching modes uses
      - code [ref=e129]: parseWithSource
      - text: ","
      - code [ref=e130]: exportWithSource
      - text: and a document-replacement transaction. The preview creates a separate read-only editor; read-only UI is not access control.
    - paragraph [ref=e131]: Images here use a bounded local file adapter. A real issue tracker supplies its own authenticated upload service, permissions and API submission. Drafts are not automatically persisted. External links and images in imported content may make network requests; this is not an offline sandbox.
    - paragraph [ref=e132]:
      - link "Developer guide ↗" [ref=e133]:
        - /url: ./developers.html
      - text: ·
      - link "Workflow API walkthrough ↗" [ref=e134]:
        - /url: https://github.com/eddolo/fountainjs/blob/master/docs/ISSUE_EDITOR_DEMO.md
      - text: ·
      - link "Demo source ↗" [ref=e135]:
        - /url: https://github.com/eddolo/fountainjs/blob/master/examples/react-app/src/IssueEditor.tsx
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | import { writeFile, readFile } from 'node:fs/promises';
  3  | import { MarkdownImporter, Schema, StarterKit } from 'fountainjs-editor';
  4  | import { issueMarkdownOptions } from '../examples/react-app/src/issue-markdown-policy';
  5  | 
  6  | test('document-boundary replacement includes a terminal atomic image', async ({ page }, info) => {
  7  |   const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jS9sAAAAASUVORK5CYII=', 'base64');
  8  |   await page.route('https://example.test/terminal-figure.png', route => route.fulfill({ contentType: 'image/png', body: png }));
  9  |   const source = 'Start here.\n\n' + Array.from({ length: 300 }, (_, index) => `Paragraph ${index + 1}.\n\n`).join('')
  10 |     + '![Terminal figure](https://example.test/terminal-figure.png)\n';
  11 |   await writeFile(info.outputPath('original.md'), source);
  12 |   await page.goto('/issue-editor.html');
  13 |   await page.getByLabel('Open Markdown draft file', { exact: true }).setInputFiles({ name: 'terminal-image.md', mimeType: 'text/markdown', buffer: Buffer.from(source) });
  14 |   const editor = page.getByRole('textbox', { name: 'Issue description editor', exact: true });
  15 |   const blocks = page.getByRole('complementary', { name: 'Fountain diagnostics' }).locator('dt:has-text("Document blocks") + dd');
  16 |   await expect(blocks).toHaveText('302 top-level blocks');
  17 |   await editor.locator(':scope > p').first().click();
  18 |   await page.keyboard.press('Control+Home');
  19 |   await page.keyboard.press('Control+Shift+End');
  20 |   const native = await page.evaluate(() => {
  21 |     const selection = getSelection();
  22 |     const path = (node: Node | null | undefined) => (node instanceof Element ? node : node?.parentElement)
  23 |       ?.closest('[data-fountain-text-path]')?.getAttribute('data-fountain-text-path');
  24 |     return { anchor: path(selection?.anchorNode), anchorOffset: selection?.anchorOffset,
  25 |       focus: path(selection?.focusNode), focusOffset: selection?.focusOffset };
  26 |   });
  27 |   await page.screenshot({ path: info.outputPath('selected-boundary.png') });
  28 |   await page.keyboard.type('Entire replacement.');
  29 |   const event = page.waitForEvent('download');
  30 |   await page.getByRole('button', { name: 'Download Markdown draft', exact: true }).click();
  31 |   await (await event).saveAs(info.outputPath('actual-replacement.md'));
  32 |   const actualSource = await readFile(info.outputPath('actual-replacement.md'), 'utf8');
  33 |   const doc = MarkdownImporter.parse(actualSource, new Schema(StarterKit.schema), issueMarkdownOptions);
  34 |   const images = doc.content.filter(node => node.type.name === 'image' || node.type.name === 'image_super').length;
  35 |   await page.screenshot({ path: info.outputPath('actual-replacement.png') });
  36 |   await writeFile(info.outputPath('observations.json'), JSON.stringify({ engine: info.project.name, native,
  37 |     actualTopLevelBlocks: doc.childCount, terminalImagesRemaining: images, actualDocument: doc.toJSON(),
  38 |     requiredBehavior: 'Ctrl+Home then Ctrl+Shift+End must include the terminal image in replacement.' }, null, 2));
> 39 |   expect(images, 'A full document-boundary selection must include the terminal atomic block.').toBe(0);
     |                                                                                                ^ Error: A full document-boundary selection must include the terminal atomic block.
  40 |   expect(doc.childCount).toBe(1);
  41 | });
  42 | 
```