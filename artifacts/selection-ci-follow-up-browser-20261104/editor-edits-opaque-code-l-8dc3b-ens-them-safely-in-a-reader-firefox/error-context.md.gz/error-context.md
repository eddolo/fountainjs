# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: editor.spec.ts >> edits opaque code labels and reopens them safely in a reader
- Location: tests\browser\editor.spec.ts:381:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "example 1 edited"
Received: "example 1"

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- main [ref=f1e3]:
  - generic [ref=f1e4]:
    - link "F FountainJS" [ref=f1e5] [cursor=pointer]:
      - /url: ./
      - generic [ref=f1e6]: F
      - text: FountainJS
    - navigation "Primary navigation" [ref=f1e7]:
      - link "Home" [ref=f1e8] [cursor=pointer]:
        - /url: ./
        - generic [ref=f1e10]: ↗
      - link "10 demos" [ref=f1e11] [cursor=pointer]:
        - /url: ./demos.html
        - generic [ref=f1e13]: ↗
      - link "Workflows" [ref=f1e14] [cursor=pointer]:
        - /url: ./workflows.html
        - generic [ref=f1e16]: ↗
      - link "Developers" [ref=f1e17] [cursor=pointer]:
        - /url: ./developers.html
        - generic [ref=f1e19]: ↗
    - link "How this is built ↓" [ref=f1e20] [cursor=pointer]:
      - /url: "#integration"
  - generic [ref=f1e21]:
    - generic [ref=f1e22]:
      - navigation "Breadcrumb" [ref=f1e23]:
        - list [ref=f1e24]:
          - listitem [ref=f1e25]:
            - link "Home" [ref=f1e26] [cursor=pointer]:
              - /url: ./
          - listitem [ref=f1e27]:
            - generic [ref=f1e28]: /
            - link "Workflow lab" [ref=f1e29] [cursor=pointer]:
              - /url: ./workflows.html
          - listitem [ref=f1e30]:
            - generic [ref=f1e31]: /
            - generic [ref=f1e32]: GitLab-style issue editor (unofficial)
        - link "Back to workflow lab" [ref=f1e33] [cursor=pointer]:
          - /url: ./workflows.html
          - generic [ref=f1e34]: ←
          - text: Back to workflow lab
      - heading "A bug report, from draft to review." [level=1] [ref=f1e35]
      - paragraph [ref=f1e36]: Write visually, inspect the Markdown, and preview what a reader sees. This is a FountainJS implementation of an issue-writing workflow, not a GitLab integration or a full GitLab Flavored Markdown implementation.
      - generic [ref=f1e37]:
        - text: Issue title
        - textbox "Issue title" [ref=f1e38]: Room switch leaves stale content
      - region "Issue description" [ref=f1e39]:
        - navigation "Description mode" [ref=f1e40]:
          - button "Visual editor" [pressed] [ref=f1e41] [cursor=pointer]
          - button "Markdown source" [ref=f1e42] [cursor=pointer]
          - button "Reader preview" [ref=f1e43] [cursor=pointer]
        - generic [ref=f1e45]:
          - toolbar "Formatting and rich content" [ref=f1e47]:
            - group "History and search" [ref=f1e48]:
              - button "Undo" [ref=f1e49] [cursor=pointer]
              - button "Redo" [disabled] [ref=f1e50]
              - button "Find and replace" [ref=f1e51] [cursor=pointer]
            - group "Block types" [ref=f1e52]:
              - button "Paragraph" [ref=f1e53] [cursor=pointer]
              - button "H1 — Heading 1" [ref=f1e54] [cursor=pointer]:
                - img:
                  - generic: H1
              - button "H2 — Heading 2" [ref=f1e55] [cursor=pointer]:
                - img:
                  - generic: H2
              - button "H3 — Heading 3" [ref=f1e56] [cursor=pointer]:
                - img:
                  - generic: H3
            - group "Text formatting" [ref=f1e57]:
              - button "Bold" [ref=f1e58] [cursor=pointer]
              - button "Italic" [ref=f1e59] [cursor=pointer]
              - button "Strikethrough" [ref=f1e60] [cursor=pointer]
              - button "Inline code" [ref=f1e61] [cursor=pointer]
              - button "Add or edit link" [ref=f1e62] [cursor=pointer]
              - button "Remove link" [disabled] [ref=f1e63]
            - group "Insert rich content" [ref=f1e64]:
              - button "Insert definition list" [ref=f1e65] [cursor=pointer]
              - button "Quote selected blocks" [ref=f1e66] [cursor=pointer]
              - button "Bullet list" [ref=f1e67] [cursor=pointer]
              - button "123 — Numbered list" [ref=f1e68] [cursor=pointer]:
                - img:
                  - generic: "1"
                  - generic: "2"
                  - generic: "3"
              - button "Task list" [ref=f1e69] [cursor=pointer]
              - button "Lift list item" [disabled] [ref=f1e70]
              - button "Indent list item" [disabled] [ref=f1e71]
              - button "Code block and language" [ref=f1e72] [cursor=pointer]
              - button "Insert table" [ref=f1e73] [cursor=pointer]
              - button "Insert image from URL" [ref=f1e74] [cursor=pointer]
              - button "Upload image" [ref=f1e75] [cursor=pointer]
              - button "Divider" [ref=f1e76] [cursor=pointer]
              - button "Line break" [ref=f1e77] [cursor=pointer]
          - textbox "Issue description editor" [active] [ref=f1e79]:
            - heading "Code label handoff edited" [level=1] [ref=f1e80]
            - paragraph [ref=f1e81]: Technical labels are data, not executable markup.
            - region "x\"y code" [ref=f1e82]:
              - text: x"y
              - code [ref=f1e83]:
                - generic [ref=f1e84]: example 1
            - region "constructor code" [ref=f1e85]:
              - text: constructor
              - code [ref=f1e86]:
                - generic [ref=f1e87]: example 2
            - region "__proto__ code" [ref=f1e88]:
              - text: __proto__
              - code [ref=f1e89]:
                - generic [ref=f1e90]: example 3
            - region "custom-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx code" [ref=f1e91]:
              - text: custom-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
              - code [ref=f1e92]:
                - generic [ref=f1e93]: example 4
            - region "<img/src=x/onerror=alert(1)> code" [ref=f1e94]:
              - text: <img/src=x/onerror=alert(1)>
              - code [ref=f1e95]:
                - generic [ref=f1e96]: example 5
      - generic [ref=f1e97]:
        - generic [ref=f1e98]: Table export
        - combobox "Table export" [ref=f1e99]:
          - option "Markdown pipes · widest compatibility" [selected]
          - option "HTML tables · preserve cell structure"
      - paragraph [ref=f1e100]: HTML tables retain supported cell roles, spans and rich content when reopened here. Other readers must support HTML tables. This choice affects regenerated tables; untouched source stays unchanged. In source mode, download saves your raw text as written.
      - generic [ref=f1e101]:
        - button "Download Markdown draft" [ref=f1e102] [cursor=pointer]
        - button "Open Markdown draft" [ref=f1e103] [cursor=pointer]
      - status [ref=f1e104]: Local demo only. Nothing is submitted to GitHub or GitLab. Download your draft before leaving.
    - complementary "Fountain diagnostics" [ref=f1e105]:
      - heading "Fountain diagnostics" [level=2] [ref=f1e106]
      - button "Check Markdown export" [ref=f1e107] [cursor=pointer]
      - paragraph [ref=f1e108]: Check the current draft before sharing. Opening source or downloading also checks it; editing stays separate.
      - generic [ref=f1e109]:
        - term [ref=f1e110]: Engine
        - definition [ref=f1e111]: FountainJS · React surface
        - term [ref=f1e112]: Document blocks
        - definition [ref=f1e113]: 7 top-level blocks
        - term [ref=f1e114]: Source preservation
        - definition [ref=f1e115]: Not checked for this draft
        - term [ref=f1e116]: Export warnings
        - definition [ref=f1e117]: Not checked for this draft
        - term [ref=f1e118]: Images
        - definition [ref=f1e119]: Local raster uploads · imported image URLs may load remotely
        - term [ref=f1e120]: Collaboration / pagination
        - definition [ref=f1e121]: Not enabled in this workflow
        - term [ref=f1e122]: Viewport rendering
        - definition [ref=f1e123]: Enabled above 250 top-level blocks
        - term [ref=f1e124]: Server runtimes
        - definition [ref=f1e125]: Not measured by this page
      - group [ref=f1e126]:
        - generic "What does preservation mean?" [ref=f1e127] [cursor=pointer]
      - generic [ref=f1e128]:
        - heading "Try the source-fidelity check" [level=3] [ref=f1e129]
        - list [ref=f1e130]:
          - listitem [ref=f1e131]: Open Markdown source and find the tilde code fence and double underscores.
          - listitem [ref=f1e132]: Return to Visual editor. Edit only the first paragraph.
          - listitem [ref=f1e133]: Switch back. Check that the untouched source is still there.
          - listitem [ref=f1e134]: Download, reopen, and preview your draft.
  - generic [ref=f1e135]:
    - heading "Build this into your product" [level=2] [ref=f1e136]
    - paragraph [ref=f1e137]:
      - text: The host owns the title, file controls and submission. Fountain owns the description model, history, selection and formatting. Switching modes uses
      - code [ref=f1e138]: parseWithSource
      - text: ","
      - code [ref=f1e139]: exportWithSource
      - text: and a document-replacement transaction. The preview creates a separate read-only editor; read-only UI is not access control.
    - paragraph [ref=f1e140]: Images here use a bounded local file adapter. A real issue tracker supplies its own authenticated upload service, permissions and API submission. Drafts are not automatically persisted. External links and images in imported content may make network requests; this is not an offline sandbox.
    - paragraph [ref=f1e141]:
      - link "Developer guide ↗" [ref=f1e142] [cursor=pointer]:
        - /url: ./developers.html
      - text: ·
      - link "Workflow API walkthrough ↗" [ref=f1e143] [cursor=pointer]:
        - /url: https://github.com/eddolo/fountainjs/blob/master/docs/ISSUE_EDITOR_DEMO.md
      - text: ·
      - link "Demo source ↗" [ref=f1e144] [cursor=pointer]:
        - /url: https://github.com/eddolo/fountainjs/blob/master/examples/react-app/src/IssueEditor.tsx
```

# Test source

```ts
  1  | import { expect, type Page, type TestInfo } from '@playwright/test';
  2  | 
  3  | export async function markdownCodeLabelsJourney(page: Page, info: TestInfo): Promise<void> {
  4  |   const labels = ['x"y', 'constructor', '__proto__', 'custom-' + 'x'.repeat(70), '<img/src=x/onerror=alert(1)>'];
  5  |   const code = labels.map((label, index) => `\`\`\`${label}\nexample ${index + 1}\n\`\`\``).join('\n\n');
  6  |   const source = '# Code label handoff\n\nTechnical labels are data, not executable markup.\n\n' + code;
  7  |   const errors: string[] = [];
  8  |   page.on('pageerror', error => errors.push(error.message));
  9  |   page.on('dialog', async dialog => { errors.push(dialog.message()); await dialog.dismiss(); });
  10 |   const capture = async (name: string) => {
  11 |     await page.evaluate(async () => { await document.fonts.ready; window.scrollTo({ top: 0, behavior: 'instant' }); });
  12 |     await page.screenshot({ path: info.outputPath(name), fullPage: true });
  13 |   };
  14 |   await page.goto('/issue-editor.html');
  15 |   await page.getByRole('button', { name: 'Markdown source', exact: true }).click();
  16 |   await page.getByLabel('Markdown description', { exact: true }).fill(source);
  17 |   await page.getByRole('button', { name: 'Visual editor', exact: true }).click();
  18 |   const editor = page.getByRole('textbox', { name: 'Issue description editor', exact: true });
  19 |   const reader = page.getByRole('textbox', { name: 'Issue preview', exact: true });
  20 |   const verify = async (surface: typeof editor, edited: boolean) => {
  21 |     await expect(surface.locator('pre')).toHaveCount(labels.length);
  22 |     for (const [index, label] of labels.entries()) {
  23 |       await expect(surface.locator('pre').nth(index)).toHaveAttribute('data-language', label);
> 24 |       await expect.poll(() => surface.locator('pre').nth(index).textContent()).toBe(`example ${index + 1}${index === 0 && edited ? ' edited' : ''}`);
     |                                                                                ^ Error: expect(received).toBe(expected) // Object.is equality
  25 |     }
  26 |     await expect(surface.locator('img,script,iframe')).toHaveCount(0);
  27 |     expect(errors).toEqual([]);
  28 |   };
  29 |   await verify(editor, false);
  30 |   for (const [index, label] of labels.entries()) await expect(editor.locator('pre').nth(index)).toHaveAttribute('title', label);
  31 |   // The generated label is not document text, but clicking it must still let
  32 |   // an author enter the code instead of typing at a stale/outside selection.
  33 |   await editor.locator('pre').first().click({ position: { x: 40, y: 24 } });
  34 |   await page.keyboard.press('End');
  35 |   await page.keyboard.type(' edited');
  36 |   await verify(editor, true);
  37 |   await page.keyboard.press('ControlOrMeta+z');
  38 |   await verify(editor, false);
  39 |   await page.keyboard.press('ControlOrMeta+Shift+z');
  40 |   await verify(editor, true);
  41 |   await capture('code-labels-editor.png');
  42 |   await page.setViewportSize({ width: 390, height: 844 });
  43 |   await verify(editor, true);
  44 |   await expect.poll(() => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  45 |   await expect.poll(() => editor.locator('pre').nth(3).evaluate(element => element.scrollWidth <= element.clientWidth)).toBe(true);
  46 |   expect(await editor.locator('pre').nth(3).evaluate(element => getComputedStyle(element, '::before').whiteSpace)).toBe('normal');
  47 |   await capture('code-labels-mobile-editor.png');
  48 |   await page.setViewportSize({ width: 1440, height: 960 });
  49 |   await page.getByRole('button', { name: 'Markdown source', exact: true }).click();
  50 |   await expect(page.getByLabel('Markdown description', { exact: true })).toHaveValue(/```x&#34;y\nexample 1 edited/);
  51 |   const download = page.waitForEvent('download');
  52 |   await page.getByRole('button', { name: 'Download Markdown draft', exact: true }).click();
  53 |   const path = info.outputPath('code-labels.md');
  54 |   await (await download).saveAs(path);
  55 |   await page.getByRole('button', { name: 'Visual editor', exact: true }).click();
  56 |   await page.getByLabel('Open Markdown draft file', { exact: true }).setInputFiles(path);
  57 |   await verify(editor, true);
  58 |   await page.getByRole('button', { name: 'Reader preview', exact: true }).click();
  59 |   await verify(reader, true);
  60 |   await capture('code-labels-reader.png');
  61 |   await page.setViewportSize({ width: 390, height: 844 });
  62 |   await verify(reader, true);
  63 |   await capture('code-labels-mobile-reader.png');
  64 | }
  65 | 
```